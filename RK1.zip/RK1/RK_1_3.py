from math import *

# Задача на движение тела брошенного под углом к горизонту

y=float(input("y = "))
x=float(input("x = "))
z=float(input("z = "))

v=float(input("Начальная скорость: "))

hor=float(input("Угол к горизонту: "))

k=float(input("Коэфф сопротивления"))

arg=float(input("угол между x и z"))

g=9.8
dt=0.01

vy = v*sin(arg)*cos(hor)
vx = v*cos(arg)*cos(hor)
vz = v*sin(hor)
while z > 0:
	x += vx*dt
    y += vy*dt
	z += vz*dt - g * dt**2 /2
    beta = atan(z/sqrt(x**2 + y**2))
    alpha = atan(y/x)
    if vx>0:
    	k  = -abs(k)
    vx += k * (vx**2 + vz**2 + vy**2)*dt*cos(alpha)*cos(beta)
    if vy>0:
    	k  = -abs(k)
    vy += k * (vx**2 + vz**2 + vy**2)*dt*sin(alpha)*cos(beta)
    if vz>0:
    	k  = -abs(k)
	vz += k * (vx**2 + vz**2 + vy**2)*dt*sin(beta) - g * dt

print("Дальность полета Тела:")
print(x, y)
