from math import *

# Задача на движение тела брошенного под углом к горизонту

h=float(input("Высота с которой брошено тело: "))

v=float(input("Начальная скорость: "))

arg=float(input("Угол к горизонту: "))

k=float(input("Коэфф сопротивления"))

g=9.8
y=h
x=0
dt=0.01


vy = v*sin(arg)
vx = v*cos(arg)
while y > 0:
	x += vx*dt
	y += vy*dt - g * dt**2 /2
    alpha = atan(y/x)
    if vx>0:
        k  = -abs(k)
    vx += k * (vx**2 + vy**2)*dt*cos(alpha)
    if vy>0:
        k  = -abs(k)
	vy += k * (vx**2 + vy**2)*dt*sin(alpha) - g * dt

print("Дальность полета Тела:")
print(x)
